'use strict';

let market = new class {
    
    addChannelItem(mapItem){

    }

    removeChannelItem(mapItem){

    }
}();

module.exports = market;